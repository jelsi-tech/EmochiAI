package com.example.emochiai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

private val Ink = Color(0xFF151321)
private val Panel = Color(0xFF242136)
private val Violet = Color(0xFF9A78FF)
private val Soft = Color(0xFFEDEAF7)

data class CharacterCard(
    val name: String,
    val description: String,
    val emoji: String,
    val personality: String
)

data class ChatMessage(val text: String, val fromUser: Boolean)

enum class ChatMode { OFFLINE, ONLINE }

interface ChatEngine {
    suspend fun reply(character: CharacterCard, history: List<ChatMessage>, userText: String): String
}

/**
 * Demonstration engine only. Replace with llama.cpp local inference before describing
 * offline replies as AI-generated.
 */
class DemoOfflineEngine : ChatEngine {
    override suspend fun reply(
        character: CharacterCard,
        history: List<ChatMessage>,
        userText: String
    ): String = "${character.name}: Me interesa lo que dices. Cuéntame un poco más para seguir nuestra historia."
}

/**
 * Secure online calls belong in a backend. This placeholder intentionally does not
 * contain provider keys or pretend to call an AI service.
 */
class OnlineChatEngine : ChatEngine {
    override suspend fun reply(
        character: CharacterCard,
        history: List<ChatMessage>,
        userText: String
    ): String = "El modo online aún necesita conectar un backend de IA seguro."
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            primary = Violet, background = Ink, surface = Panel,
            onBackground = Soft, onSurface = Soft
        )) { EmochiApp() } }
    }
}

@Composable
fun EmochiApp() {
    val characters = remember {
        listOf(
            CharacterCard("Akira", "Aventurera • Anime", "🌙", "Valiente, curiosa y leal"),
            CharacterCard("Mika", "Compañera • Fantasía", "✨", "Amable, ingeniosa y divertida"),
            CharacterCard("Ren", "Rival • Acción", "⚔️", "Reservado, competitivo y honorable")
        )
    }
    var selected by remember { mutableStateOf<CharacterCard?>(null) }
    var mode by remember { mutableStateOf(ChatMode.OFFLINE) }

    Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
        if (selected == null) {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Text("Emochi AI", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Soft)
                Text("Tus historias empiezan aquí", color = Color(0xFFBDB7D3))
                Spacer(Modifier.height(20.dp))
                ModeSelector(mode) { mode = it }
                Spacer(Modifier.height(18.dp))
                Text("Personajes", fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(characters) { character ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { selected = character },
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(character.emoji, fontSize = 36.sp)
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(character.name, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                    Text(character.description, color = Color(0xFFBDB7D3))
                                    Text(character.personality, color = Violet, fontSize = 13.sp)
                                }
                                Text("Chatear  ›", color = Violet)
                            }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("Versión inicial • El motor de IA aún debe integrarse", color = Color(0xFFAAA4C0), fontSize = 12.sp)
            }
        } else {
            ChatScreen(
                character = selected!!,
                mode = mode,
                onModeChange = { mode = it },
                onBack = { selected = null }
            )
        }
    }
}

@Composable
fun ModeSelector(mode: ChatMode, onChange: (ChatMode) -> Unit) {
    Column {
        Text("Modo de conversación", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = mode == ChatMode.OFFLINE,
                onClick = { onChange(ChatMode.OFFLINE) },
                label = { Text("📱 Sin internet") }
            )
            FilterChip(
                selected = mode == ChatMode.ONLINE,
                onClick = { onChange(ChatMode.ONLINE) },
                label = { Text("🌐 Online") }
            )
        }
    }
}

@Composable
fun ChatScreen(
    character: CharacterCard,
    mode: ChatMode,
    onModeChange: (ChatMode) -> Unit,
    onBack: () -> Unit
) {
    val history = remember(character.name) {
        mutableStateListOf(ChatMessage("${character.name}: ¡Hola! ¿Qué aventura viviremos hoy?", false))
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Volver") }
            Column(Modifier.weight(1f)) {
                Text("${character.emoji} ${character.name}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(if (mode == ChatMode.OFFLINE) "Modo sin conexión" else "Modo online", color = Violet, fontSize = 12.sp)
            }
            Box {
                var expanded by remember { mutableStateOf(false) }
                TextButton(onClick = { expanded = true }) { Text(if (mode == ChatMode.OFFLINE) "Offline ▾" else "Online ▾") }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    DropdownMenuItem(text = { Text("Sin internet") }, onClick = { onModeChange(ChatMode.OFFLINE); expanded = false })
                    DropdownMenuItem(text = { Text("Online") }, onClick = { onModeChange(ChatMode.ONLINE); expanded = false })
                }
            }
        }
        Divider(color = Panel)
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(history) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                    Text(
                        msg.text,
                        modifier = Modifier.widthIn(max = 310.dp)
                            .background(if (msg.fromUser) Color(0xFF51417D) else Panel, RoundedCornerShape(16.dp))
                            .padding(12.dp),
                        color = Soft
                    )
                }
            }
            if (busy) item { Text("Escribiendo…", color = Violet) }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f).padding(8.dp),
                textStyle = androidx.compose.ui.text.TextStyle(color = Soft, fontSize = 16.sp),
                decorationBox = { inner ->
                    if (input.isEmpty()) Text("Escribe un mensaje…", color = Color.Gray)
                    inner()
                }
            )
            IconButton(enabled = input.isNotBlank() && !busy, onClick = {
                val text = input.trim()
                input = ""
                history.add(ChatMessage(text, true))
                busy = true
                // Demo engine is intentionally simple. Replace with real local inference / backend.
                val engine: ChatEngine = if (mode == ChatMode.OFFLINE) DemoOfflineEngine() else OnlineChatEngine()
                kotlinx.coroutines.GlobalScope.launch(Dispatchers.Main) {
                    val answer = withContext(Dispatchers.Default) { engine.reply(character, history.toList(), text) }
                    history.add(ChatMessage(answer, false))
                    busy = false
                }
            }) {
                Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Violet)
            }
        }
    }
}
