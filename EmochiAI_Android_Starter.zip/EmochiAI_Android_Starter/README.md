# Emochi AI - Android Starter

Proyecto inicial para Android Studio (Kotlin + Jetpack Compose).

## Incluye
- Pantalla inicial con personajes de ejemplo.
- Chat local de demostración e historial en memoria durante la sesión.
- Selector de modo Online / Offline.
- Interfaces separadas para el motor online y el motor local.

## Importante
Este starter NO es todavía una APK compilada y NO incluye un modelo de IA. El modo offline usa una respuesta de demostración hasta que se integre un modelo GGUF compatible mediante llama.cpp. El modo online necesita un backend real configurado.

## Abrir
1. Descomprime el ZIP.
2. Abre la carpeta `EmochiAI_Android_Starter` en Android Studio.
3. Deja que Gradle sincronice.
4. Ejecuta en un dispositivo Android o emulador.

## Para añadir IA real
- Offline: integrar llama.cpp / Android NDK y permitir que el usuario importe un archivo GGUF pequeño compatible. El modelo no debe incluirse en el APK.
- Online: crea un backend HTTPS que guarde la clave del proveedor de IA en el servidor; configura `OnlineChatEngine` para llamar a ese backend. No pongas claves secretas dentro del APK.

El proyecto es una base de desarrollo. Debe compilarse y probarse en Android Studio antes de distribuirse.
